package com.galaxy.exceptions;

public class UnknownSymbolException extends Exception {

	public UnknownSymbolException(String message) {
		super(message);
	}

}
