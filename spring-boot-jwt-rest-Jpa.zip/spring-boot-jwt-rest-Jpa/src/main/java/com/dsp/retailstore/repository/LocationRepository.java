package com.dsp.retailstore.repository;

import org.springframework.data.repository.CrudRepository;

import com.dsp.retailstore.model.Location;
/**
 * 
 * @author damujuri
 *
 */
public interface LocationRepository extends CrudRepository<Location, Long> {

}