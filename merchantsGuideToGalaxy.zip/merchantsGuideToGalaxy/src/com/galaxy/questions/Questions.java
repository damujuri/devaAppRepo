package com.galaxy.questions;

import java.util.ArrayList;
import java.util.List;

public class Questions {
	
	List<String> questions = new ArrayList<String>();
	
	public List<String> getAllQuestions() {
		return questions;
	}

}
